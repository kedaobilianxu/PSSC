 clear; close all; clc;

addpath('./funs');
addpath('./Datasets/HSI-LiDAR-Trento');


dataType = 'Trento';   
%dataType = 'MUUFL'; 
%dataType = 'Houston'; 
%dataType = 'Augsburg';
%dataType = 'MDAS';


fprintf('Dataset : %s\n', dataType);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%超参数调整%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%beta = [0.5:0.1:1];
%w_d = [10:10:50];
%M = [6:6:120];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Trento%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 beta = [0.1];
 M = [28];
%36 Kappa = 0.8647
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%MUUFL(暂时)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %beta = [0.1:0.1:1];
 %M = [12:1:100];
%  w_d = [50];
%47 Kappa = 0.3567
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Houston(暂时)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %beta = [0.1];
 %M = [15];
% w_d = [40];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Augsburg%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% beta = [0.1];
% M = [51];
% w_d = [40];
%%% data3D, sar3D, dsm2D
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%MDAS%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% beta = [0.2];
% M = [16];
% w_d = [40];
%%% data3D, sar3D, msi3D, dsm2D
row_index = 2;
[data3D, lidar2D, sar3D, msi3D, dsm2D, gt, ind, c] = loadHSI_new(dataType);
data3D = data3D./max(data3D(:));
lidar2D = lidar2D./max(lidar2D(:));
sar3D = sar3D./max(sar3D(:));
msi3D = msi3D./max(msi3D(:));
dsm2D = dsm2D./max(dsm2D(:));

data3D = double(data3D);
lidar2D = double(lidar2D);
sar3D = double(sar3D);
msi3D = double(msi3D);
dsm2D = double(dsm2D);

[nr,nc,~] = size(data3D);
for betai = 1:size(beta,2)
    fprintf('Beta : %f\n', beta(betai));
    for M_i = 1:size(M,2)
            tic;
            %[y_pred] = TBD_M(data3D, sar3D, msi3D, dsm2D, beta(betai), M(M_i), ind, gt, c);
            [y_pred] = TBD(data3D, lidar2D, beta, M, ind, gt, c);
            %[y_pred] = TBD_A(data3D, sar3D, dsm2D, beta, M, ind, gt, c);
            running_time = toc;
            [result,PA, UA, AA, OA, Kappa] = HSI_ClusteringMeasure1(gt(ind),y_pred(ind));
            results = [beta(betai), M(M_i), AA, OA, Kappa,running_time];

            fprintf('cluster result of TBD\n');
            for i = 1:4
                varName = {'AA', 'OA', 'Kappa', 'running_time'};
                varValue = [AA, OA, Kappa, running_time];
                fprintf('%s ： %f\n', varName{i}, varValue(i));
            end
    end
end

